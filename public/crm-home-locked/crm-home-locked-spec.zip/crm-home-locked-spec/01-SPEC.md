# SPEC — CRM Начало (заключена версия)

Цел: **1:1 клонинг** на desktop CRM home. Минимална сходство **98%**, цел **100%**.

Референции:

- `references/dark-locked.jpg` — тъмна тема (нощна вила + pool)
- `references/light-locked.jpg` — светла тема (ден/здрач вила + pool)
- `references/broker-placement.jpg` — аватар + име долу вляво

Стек: **React 19 + Vite 7 + React Three Fiber** (фото-plane фон) + DOM overlay (UI).

---

## 1. Viewport и layout

| Зона | Позиция | Описание |
|------|---------|----------|
| Background | `fixed inset-0` | Full-bleed фото, `object-fit: cover`, `object-position: center` |
| Logo | top-left | ~`left: 2.5vw; top: 2.2vh`; ширина ~72–88px |
| Nav | top-right | ~`right: 3vw; top: 2.5vh`; 5 items в ред |
| Cards grid | center-right | 2×2; заема ~42–48% от ширината; `right: 4vw`; вертикално центрирана леко надолу от средата |
| Broker badge | bottom-left | ~`left: 2.5vw; bottom: 3vh` |
| Utility dock | bottom-right | ~`right: 2.5vw; bottom: 3vh` |
| Bottom sheet | отдолу | отваря се от hamburger; покрива ~45% височина |

**Забранено:** ляв sidebar; долни 4 малки KPI пилчета; paint-splash / четки.

Aspect: дизайнът е за **16:9 desktop**. На по-тесни екрани картите остават 2×2 но по-малки; фонът продължава cover.

---

## 2. Цветове и типография

### Цветове (и двете теми)

| Token | Стойност | Употреба |
|-------|----------|----------|
| `--ui-white` | `#FFFFFF` | текст, икони, рамки |
| `--glow` | `rgba(255,255,255,0.55–0.85)` | box-shadow / drop-shadow |
| `--glass` | dark: `rgba(12,16,24,0.42)`; light: `rgba(255,255,255,0.16)` | лява половина на карта |
| `--glass-blur` | `18px` | backdrop-filter |
| `--card-radius` | `24px` | border-radius |
| `--card-border` | `1.5–2px solid rgba(255,255,255,0.85)` | рамка |
| `--active-underline` | `#fff` + glow | активен nav item |

### Шрифтове

- Family: **"Montserrat"**, fallback `Inter, system-ui, sans-serif`
- Зареди Google Fonts: `Montserrat:wght@400;500;600;700;800`
- Nav labels: 11–12px, weight 500, letter-spacing 0.02em
- Card number: 42–56px, weight 800
- Card title: 18–22px, weight 600
- Card subtitle „Реални данни“: 12–13px, weight 400, opacity 0.85
- Broker name: 16–18px, weight 600

Всички UI текстове са **бели** (и в light тема — бели върху стъкло/glow).

---

## 3. Лого

- Файл: `assets/logo-white.svg` (или `logo-white.png`)
- Цвят: чисто бяло
- Ефект: `filter: drop-shadow(0 0 8px rgba(255,255,255,0.75))`
- **Без** бордо фон, **без** бяла плоча, **без** brush splash зад логото
- Alt: `Недвижими имоти Надежда`

---

## 4. Навигация (top-right)

5 items, вертикален стек икона→текст за всеки:

| Key | Label | Lucide icon |
|-----|-------|-------------|
| home | Начало | `Home` |
| clients | Клиенти | `Users` |
| properties | Имоти | `Building2` |
| ai | AI асистент | `Sparkles` |
| calendar | Календар | `Calendar` |

- Gap между items: ~28–36px
- Активен (`home` по подразбиране): дебела светеща линия под иконата (~28px широка, 3px висока, `box-shadow: 0 0 12px #fff`)
- Hover: opacity 1; inactive opacity ~0.82
- Click: set active + navigate / hash (`#clients` и т.н. в клонинга)

---

## 5. Карти (2×2) — критично

Ред:

1. **Клиенти** — value `1` — icon Users — photo `card-klienti.jpg` — href `/admin/clients`
2. **Активни имоти** — value `1` — icon Building2 — photo `card-imoti.jpg` — href `/admin/properties`
3. **Активни сделки** — value `0` — icon Handshake — photo `card-sdelki.jpg` — href `/admin/deals`
4. **Огледи** — value `0` — icon CalendarClock — photo `card-ogledi.jpg` — href `/admin/viewings`

### Геометрия на една карта

- Aspect ~ 1.35–1.5 (по-широка от висока)
- Gap в grid: 16–20px
- Лек tilt **не е задължителен** в заключените референции — картите са прави (без 3D skew). Не добавяй rotateY.
- Рамка: glow + inset highlight (виж `03-EFFECTS.md`)

### Хоризонтално преливане (ЗАДЪЛЖИТЕЛНО)

```
[  INFO / GLASS  ||||| PHOTO          ]
[  icon          |                    ]
[  NUMBER        |   sunny property   ]
[  Title         |                    ]
[  Реални данни  |                    ]
[  (→) button    |                    ]
```

- Фото слой: absolute, inset 0, `background-size: cover`, `background-position: 70% center`
- Mask на фото: `linear-gradient(to right, transparent 0%, transparent 38%, #000 58%, #000 100%)`
- Glass overlay ляво: `linear-gradient(to right, var(--glass) 0%, var(--glass) 42%, transparent 62%)` + `backdrop-filter: blur(18px)` на цялата карта или на ляв панел
- **Не** вертикален fade отдолу нагоре
- **Не** плътен бял блок

### Съдържание вляво (padding ~18–22px)

1. Кръгла икона (36px) с тънък бял пръстен + lucide 18px
2. Голяма цифра
3. Заглавие
4. „Реални данни“
5. Кръгъл бутон стрелка долу вляво (36px), `aria-label` според картата

---

## 6. Broker badge (bottom-left)

От `references/broker-placement.jpg`:

- Кръгъл аватар 56–64px, border `2px solid rgba(255,255,255,0.9)`, glow
- Текст вдясно: **Мирослав Канев** (бял)
- Под името: къса хоризонтална светеща линия (~48–64px, 2px, gold-white)
- Click / Link → `/admin/profile`

---

## 7. Utility dock (bottom-right)

### Тъмна тема

1. Bell (notifications) — кръг ~44px
2. Menu (hamburger) — кръг ~52px, по-силен glow

### Светла тема

1. Sun (theme toggle към dark) — кръг ~44px  
2. Bell  
3. Menu  

Всички: `border: 1.5px solid rgba(255,255,255,0.85)`, `backdrop-filter: blur(10px)`, `background: rgba(255,255,255,0.08)`.

### Поведения

| Control | Behavior |
|---------|----------|
| Sun | `setTheme(theme === 'light' ? 'dark' : 'light')` |
| Bell | `setNotificationsOpen(true)` — реален панел с поне 1 ред текст |
| Menu | `setMenuOpen(true)` — bottom sheet с 5 nav items + close |
| Card arrow / card click | navigate to mapped route |
| Nav item | setActive + navigate |

---

## 8. React Three Fiber фон

Компонент `SceneBackdrop`:

- `<Canvas>` absolute inset-0, `pointer-events: none`, z-index 0
- Orthographic или perspective camera; plane с текстура `bg-dark.jpg` / `bg-light.jpg`
- Лек bloom **не е задължителен**; ако липсва drei Bloom — само texture plane
- DOM UI е `z-index: 1` отгоре

Ако R3F се зареди бавно — fallback `<img>` със същия asset (без визуална разлика в cover).

---

## 9. Файлова структура (клон)

```
src/routes/crm-home-locked.tsx
src/components/crm-home-locked/
  CrmHomeLockedPage.tsx
  LockedLogo.tsx
  LockedNav.tsx
  GlassStatCard.tsx
  BrokerBadge.tsx
  UtilityDock.tsx
  BottomMenuSheet.tsx
  NotificationsPanel.tsx
  SceneBackdrop.tsx
  crm-home-locked.css
public/crm-home-locked/*
```

Виж `02-COMPONENT-TREE.md`.

---

## 10. Responsive бележки

- < 900px: grid 2×2 с по-малки карти; nav icons without labels OK
- Менюто винаги достъпно през hamburger
- Фонът винаги cover

---

## 11. Copy (точни низове)

- Начало, Клиенти, Имоти, AI асистент, Календар
- Клиенти / Активни имоти / Активни сделки / Огледи
- Реални данни
- Мирослав Канев
