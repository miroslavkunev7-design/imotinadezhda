# CRM Home Locked — Clone Spec Pack

Този ZIP е пълната спецификация за 1:1 клонинг на заключеното CRM Начало (светла + тъмна).

## Старт

1. Прочети `00-RULES.md` — задължително.
2. Следвай `01-SPEC.md` + `03-EFFECTS.md`.
3. Ползвай само `assets/` според `04-ASSETS-MAP.md`.
4. Имплементирай дървото от `02-COMPONENT-TREE.md`.
5. Не спирай преди `05-ACCEPTANCE.md` = PASS (≥98%).

## Референции

- `references/dark-locked.jpg`
- `references/light-locked.jpg`
- `references/broker-placement.jpg`

## Жива страница в проекта

Маршрут: `/crm-home-locked`
