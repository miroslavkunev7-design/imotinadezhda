# ASSETS MAP

Всички пътища са относителни към корена на ZIP-а / към `/crm-home-locked/` в public.

| Файл | Къде се слага | Как |
|------|---------------|-----|
| `assets/bg-dark.jpg` | R3F plane / fallback `<img>` при `theme=dark` | `object-fit: cover`, full viewport |
| `assets/bg-light.jpg` | същото при `theme=light` | `object-fit: cover` (portrait → center crop OK) |
| `assets/logo-white.svg` | LockedLogo top-left | width ~80px, drop-shadow glow, без фон |
| `assets/logo-white.png` | fallback ако SVG липсва | същото |
| `assets/logo-banner.png` | **не** за тази страница (референция само) | — |
| `assets/avatar-miroslav.jpg` | BrokerBadge кръг | `object-fit: cover`, 60×60 |
| `assets/card-klienti.jpg` | GlassStatCard „Клиенти“ дясна половина | cover, mask horizontal |
| `assets/card-imoti.jpg` | „Активни имоти“ | cover, mask |
| `assets/card-sdelki.jpg` | „Активни сделки“ | cover, mask |
| `assets/card-ogledi.jpg` | „Огледи“ | cover, mask |
| `references/dark-locked.jpg` | QA сравнение | не се показва в UI |
| `references/light-locked.jpg` | QA сравнение | не се показва в UI |
| `references/broker-placement.jpg` | QA за позиция аватар+име | не се показва в UI |

## Public runtime paths

```
/crm-home-locked/bg-dark.jpg
/crm-home-locked/bg-light.jpg
/crm-home-locked/logo-white.svg
/crm-home-locked/avatar-miroslav.jpg
/crm-home-locked/card-klienti.jpg
/crm-home-locked/card-imoti.jpg
/crm-home-locked/card-sdelki.jpg
/crm-home-locked/card-ogledi.jpg
```

## Забранени ассети за тази страница

- бордо brush banners
- paint-splash masks върху картите
- каквито и да е stock изображения извън тази папка
