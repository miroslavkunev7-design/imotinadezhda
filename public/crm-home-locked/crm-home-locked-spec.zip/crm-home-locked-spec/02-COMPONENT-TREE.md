# Component tree

```
CrmHomeLockedPage
├── SceneBackdrop          # R3F Canvas + textured plane (bg-dark | bg-light)
├── LockedLogo             # white SVG, drop-shadow glow
├── LockedNav              # 5 items, active underline
├── section.cards (grid)
│   ├── GlassStatCard ×4   # horizontal blend
├── BrokerBadge            # avatar + Мирослав Канев
├── UtilityDock            # sun? + bell + menu
├── NotificationsPanel     # state-controlled
└── BottomMenuSheet        # state-controlled
```

## Файлове за създаване

| Файл | Отговорност |
|------|-------------|
| `src/routes/crm-home-locked.tsx` | TanStack route `/crm-home-locked`, head noindex |
| `src/components/crm-home-locked/CrmHomeLockedPage.tsx` | theme state, layout shell |
| `LockedLogo.tsx` | img/svg from `/crm-home-locked/logo-white.svg` |
| `LockedNav.tsx` | activeKey, onNavigate |
| `GlassStatCard.tsx` | props: title, value, icon, photoUrl, href |
| `BrokerBadge.tsx` | avatar + name + glow line |
| `UtilityDock.tsx` | theme, notifications, menu callbacks |
| `BottomMenuSheet.tsx` | open/onClose, items |
| `NotificationsPanel.tsx` | open/onClose |
| `SceneBackdrop.tsx` | R3F + fallback img |
| `crm-home-locked.css` | glow, glass, blend masks |

## Props контракти

```ts
type ThemeMode = "dark" | "light";

type NavKey = "home" | "clients" | "properties" | "ai" | "calendar";

type GlassStatCardProps = {
  title: string;
  value: string | number;
  subtitle?: string; // default "Реални данни"
  photoUrl: string;
  href: string;
  icon: React.ReactNode;
};
```

## State в CrmHomeLockedPage

```ts
const [theme, setTheme] = useState<ThemeMode>("light"); // или dark — и двете валидни
const [activeNav, setActiveNav] = useState<NavKey>("home");
const [menuOpen, setMenuOpen] = useState(false);
const [notificationsOpen, setNotificationsOpen] = useState(false);
```

При `theme === "light"`: `bg-light.jpg`, sun icon видим.
При `theme === "dark"`: `bg-dark.jpg`, sun icon скрит (или moon за обратно).
