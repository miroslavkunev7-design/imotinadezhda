# EFFECTS — glow, glass, хоризонтално преливане

## 1. Card glow border

```css
.crm-locked-card {
  position: relative;
  border-radius: 24px;
  border: 1.5px solid rgba(255, 255, 255, 0.88);
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.25),
    0 0 22px rgba(255, 255, 255, 0.55),
    0 0 48px rgba(255, 255, 255, 0.22),
    inset 0 0 18px rgba(255, 255, 255, 0.12);
  overflow: hidden;
  isolation: isolate;
}
```

## 2. Glass body

```css
.crm-locked-card {
  background: rgba(255, 255, 255, 0.06);
  backdrop-filter: blur(18px) saturate(140%);
  -webkit-backdrop-filter: blur(18px) saturate(140%);
}
[data-theme="dark"] .crm-locked-card {
  background: rgba(8, 12, 20, 0.28);
}
[data-theme="light"] .crm-locked-card {
  background: rgba(255, 255, 255, 0.14);
}
```

## 3. Хоризонтално преливане (фото слой)

Слоят снимка е **под** текста, mask изрязва лявото:

```css
.crm-locked-card__photo {
  position: absolute;
  inset: 0;
  background-size: cover;
  background-position: 72% center;
  z-index: 0;
  -webkit-mask-image: linear-gradient(
    to right,
    transparent 0%,
    transparent 36%,
    rgba(0, 0, 0, 0.55) 50%,
    #000 62%,
    #000 100%
  );
  mask-image: linear-gradient(
    to right,
    transparent 0%,
    transparent 36%,
    rgba(0, 0, 0, 0.55) 50%,
    #000 62%,
    #000 100%
  );
}
```

Ляв glass veil (прозрачен, не плътно бяло):

```css
.crm-locked-card__veil {
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  background: linear-gradient(
    to right,
    rgba(10, 14, 22, 0.55) 0%,
    rgba(10, 14, 22, 0.38) 40%,
    rgba(10, 14, 22, 0.08) 55%,
    transparent 68%
  );
}
[data-theme="light"] .crm-locked-card__veil {
  background: linear-gradient(
    to right,
    rgba(255, 255, 255, 0.28) 0%,
    rgba(255, 255, 255, 0.16) 40%,
    rgba(255, 255, 255, 0.04) 55%,
    transparent 68%
  );
}
```

Съдържанието (цифра, текст) е `z-index: 2`, `position: relative`.

### Грешни варианти (НЕ)

- `linear-gradient(to top, white, transparent)` — това е вертикално
- Плътен `background: #fff` на лявата половина
- Снимка full-bleed без mask (картата изглежда „запълнена“)

## 4. Logo glow

```css
.crm-locked-logo {
  filter: drop-shadow(0 0 6px rgba(255, 255, 255, 0.85))
    drop-shadow(0 0 16px rgba(255, 255, 255, 0.45));
}
```

## 5. Nav active underline

```css
.crm-locked-nav__item--active::after {
  content: "";
  display: block;
  width: 28px;
  height: 3px;
  margin: 6px auto 0;
  border-radius: 999px;
  background: #fff;
  box-shadow: 0 0 10px rgba(255, 255, 255, 0.95), 0 0 18px rgba(255, 255, 255, 0.6);
}
```

## 6. Utility circle

```css
.crm-locked-fab {
  width: 48px;
  height: 48px;
  border-radius: 999px;
  border: 1.5px solid rgba(255, 255, 255, 0.9);
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(12px);
  box-shadow: 0 0 16px rgba(255, 255, 255, 0.45);
  color: #fff;
}
.crm-locked-fab--menu {
  width: 56px;
  height: 56px;
  box-shadow: 0 0 22px rgba(255, 255, 255, 0.65);
}
```

## 7. Avatar ring

```css
.crm-locked-avatar {
  width: 60px;
  height: 60px;
  border-radius: 999px;
  object-fit: cover;
  border: 2px solid rgba(255, 255, 255, 0.95);
  box-shadow: 0 0 14px rgba(255, 255, 255, 0.7);
}
.crm-locked-name-line {
  width: 56px;
  height: 2px;
  margin-top: 6px;
  border-radius: 999px;
  background: linear-gradient(90deg, #f0d78c, rgba(255, 255, 255, 0.9));
  box-shadow: 0 0 8px rgba(240, 215, 140, 0.8);
}
```

## 8. Наслагване (z-index)

```
0  SceneBackdrop / fallback img
1  Logo, Nav, Cards, Broker, Utility
50 BottomMenuSheet / NotificationsPanel overlays
```
