import type { ReactNode } from "react";

export type GlassCardProps = {
  title: string;
  value: string | number;
  subtitle?: string;
  photoUrl: string;
  href: string;
  icon: ReactNode;
};

/** Reference implementation of horizontal-blend glass card. */
export function GlassCard({
  title,
  value,
  subtitle = "Реални данни",
  photoUrl,
  href,
  icon,
}: GlassCardProps) {
  return (
    <a className="crm-locked-card" href={href}>
      <div
        className="crm-locked-card__photo"
        style={{ backgroundImage: `url(${photoUrl})` }}
        aria-hidden
      />
      <div className="crm-locked-card__veil" aria-hidden />
      <div className="crm-locked-card__body">
        <div className="crm-locked-card__icon">{icon}</div>
        <div className="crm-locked-card__value">{value}</div>
        <div className="crm-locked-card__title">{title}</div>
        <div className="crm-locked-card__sub">{subtitle}</div>
        <span className="crm-locked-card__arrow" aria-hidden>
          →
        </span>
      </div>
    </a>
  );
}
