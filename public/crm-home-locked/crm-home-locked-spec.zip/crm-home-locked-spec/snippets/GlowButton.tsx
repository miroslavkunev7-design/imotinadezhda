import type { ButtonHTMLAttributes, ReactNode } from "react";

type GlowButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  size?: "md" | "lg";
};

export function GlowButton({ children, size = "md", className = "", ...rest }: GlowButtonProps) {
  const dim = size === "lg" ? 56 : 48;
  return (
    <button
      type="button"
      className={`crm-locked-fab ${size === "lg" ? "crm-locked-fab--menu" : ""} ${className}`}
      style={{ width: dim, height: dim }}
      {...rest}
    >
      {children}
    </button>
  );
}
